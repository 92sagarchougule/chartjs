async function logJSONData() {
    const response = await fetch("http://uatapi_mat.mahaitgov.in/graphical_data");
    const jsonData = await response.json();
    console.log(jsonData);
  }